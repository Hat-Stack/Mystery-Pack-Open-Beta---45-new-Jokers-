
-- The Dud
SMODS.Joker{
	key = "dud",
	atlas = "jokers",
	pos = {x=6,y=2},
	rarity = 3,
	cost = 1,
	blueprint_compat = true,
	perishable_compat= true,
	eternal_compat = true
}
